<template>
    <div id="top-navbar">
        <CompLogo></CompLogo>
    </div>
</template>

<script>
    import CompLogo from "./CompLogo";

    export default {
        name: "TopNavbar",
        components: {CompLogo}
    }
</script>

<style scoped>

</style>
