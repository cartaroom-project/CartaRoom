<template>
    
</template>

<script>
    export default {
        name: "ReviewListItem"
    }
</script>

<style scoped>

</style>
