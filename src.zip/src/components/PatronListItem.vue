<template>
    <div class="patron-list-item">
        <input type="checkbox" id="scales" name="scales"
               checked>
        <label for="scales">Scales</label>
    </div>
</template>

<script>
    export default {
        name: "PatronListItem"
    }
</script>

<style scoped>

</style>
