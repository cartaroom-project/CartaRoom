<template>
    <div id="comp-logo-place">
        <img id="comp-logo" src="../assets/Final_CartaRoom.png"/>
    </div>
</template>

<script>
    export default {
        name: "CompLogo"
    }
</script>

<style scoped>
    #comp-logo {
        max-width: 30%;
        min-width: 18%;
        height: auto;
    }

    #comp-logo-place {
        display: inline-block;
        align: left;

    }
</style>
