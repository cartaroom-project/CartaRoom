<template>
    <div class="confirmation" >
        <p>This action was successful!</p>
        <button>continue</button>
    </div>
</template>

<script>
    export default {
        name: "Confirmation"
    }
</script>

<style scoped>

</style>
