<template>
    <div class="patron-history">
        <div class="patron-history-action-bar">
            Room: Title
        </div>
        <div class="patron-history-list">
            <patron-list-item></patron-list-item>
        </div>
    </div>
</template>

<script>
    export default {
        name: "RoomHistory"
    }
</script>

<style scoped>

</style>
