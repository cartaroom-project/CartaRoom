<template>
    <div class="profile">
        <div class="banner">
            <h1>Profile</h1>
        </div>
        <div class="user">
            <h2>Name: </h2>
            <p>Description:</p>
            <p>Email:</p>
            <p>Phone:</p>
        </div>
        <div class="room">
            <h2>Available Rooms</h2>
            <p>Rooms:</p>
        </div>
        <div class="type">
            <h2>Free Account</h2>
            <button>Upgrade Now</button>
        </div>
    </div>
</template>