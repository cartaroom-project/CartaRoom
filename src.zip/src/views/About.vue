<template>
    <div class="about">
        <div class = "banner">
            <h1>ABOUT US</h1>
        </div>
        <div class="info">
            <h3>What is CartaRoom?</h3>
            <p>
                CartaRoom is a convenient online room management service that connects
                local businesses with customers who need a temporary space.
            </p>
            <h3>Hosts:</h3>
            <p>With CartaRoom, you can put public cpace up for reservation. Elminating
                the use of pen and paper because everything is done online. Not only
                can you virtually manage your rooms, but you'll be able to see the analytics
                for people who come and go.
            </p>
            <h3>Patrons:</h3>
            <p>You can browse and see everything online and make the reservations directly through
                CartaRoom. No need to check in person if a place has any last minute openings
                as CartaRoom can give you the most up to date information!
            </p>
            <h3>Who is potatum?</h3>
            <p>The team at potatum is newly founded by five dedicated BCIT students from the
                Computer Systems Technology program. With over a combined decade of customers
                relation management and leadership experience, the team excels in handling any
                converns and problem solving.
            </p>

            <h3>THIS IS DUMMY TEXT</h3>
            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                deserunt mollit anim id est laborum."
            </p>

            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                deserunt mollit anim id est laborum."
            </p>

            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                deserunt mollit anim id est laborum."
            </p>

            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                deserunt mollit anim id est laborum."
            </p>

        </div>
    </div>
</template>
