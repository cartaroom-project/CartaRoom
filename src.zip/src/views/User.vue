<template>
  <div class="User">
    <h1>You are not admin, buy our premium plan for ONLY $99999.99</h1>
  </div>
</template>
