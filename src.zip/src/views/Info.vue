<template>
  <div class="info">
    <h1>This is an Info page</h1>
  </div>
</template>
